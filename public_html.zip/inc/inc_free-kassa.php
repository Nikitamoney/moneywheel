<? 
//id мерчанта фри-кассы
$free_merchant_id = '12345';

//секретный ключ фри-кассы
$free_merchant_secret = '123456';

//секретный ключ фри-кассы 2
$free_merchant_secret2 = '123456';
?>