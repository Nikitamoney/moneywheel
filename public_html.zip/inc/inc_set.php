<?php
//ID приложения
$vk_app_id = '';
//защищённый ключ
$vk_secret = '';
//адрес сайта (заменить только домен!)
$vk_login_url = '';

//id чата вк, он же и id приложения
$chat_vk_id = '123456';

//ключевые слова
$site_keywords = 'ВАШЕ ЛОГО, моментальная лотерея, лотеря с противником, играть в онлайн лотерею';

//лого сайта
$site_logo = '<span class="logo_qw">ВАШЕ </span><span class="logo_qa"> ЛОГО</span>';

//слоган под лого
$site_slogan = '<div class="logo_slogan">сервис быстрых лотерей</div>';

//название сайта в футере
$site_title_footer = 'scripts-ferm.ru';

//название сайта используется в правилах и на других страницах
$site_title_main = '<span style="color: #1088ee;">scripts-ferm.ru форум экономических игр хайпов</span><span style="color: #FF6A00;">scripts-ferm.ru форум экономических игр хайпов</span>';

//группа вк
$site_vk_pub = 'https://vk.com/вашагруппа';

//информация (выводится в контактах)
$site_info_contacts = 'Риповано админом сайта scripts-ferm.ru';

//EMAIL сайта (выводится в контактах)
$site_email_contacts = 'hdhewn@bk.ru';

//баннеры для приглашения рефералов (выводятся на странице сайт.ру/refs)
$site_ref_promo_banner_1 = '<img src="/img/468_1.gif" width="468" height="60">';
$site_ref_promo_banner_2 = '<img src="/img/468_2.gif" width="468" height="60">';
$site_ref_promo_banner_3 = '<img src="/img/468.gif" width="468" height="60">';
$site_ref_promo_banner_4 = '<img src="/img/468_1(1).gif" width="468" height="60">';

//место под баннер 468x60

$banner_content = '';
?>