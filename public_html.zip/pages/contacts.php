<?
if ($mode == 'contacts') {
?>

<div class="content">

<div class="h1_content">КОНТАКТЫ</div>
<div style="text-align: left; margin-bottom: 30px;">
<?echo $site_info_contacts?>

<br/>
<br/>
Email: <?echo $site_email_contacts?>
</div>
</div>

<?}?>